<?php


namespace app\common\model;


use think\Model;

class AutoAppRefush extends Model
{
    protected $table="auto_app_refush";



}