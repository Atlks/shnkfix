<?php

namespace app\common\model;

use think\Model;

/**
 * 重签收费
 */
class ProxyResignFree extends Model
{
    protected $table='proxy_resign_free';
}
