<?php


namespace app\common\model;


use think\Model;

class appEarlyWarning extends Model
{
    protected $table="proxy_app_early_warning";

}