<?php


namespace app\common\model;


use think\Model;

class AppDevicetoken extends Model
{
    protected $table="proxy_app_devicetoken";

}