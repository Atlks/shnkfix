<?php


namespace app\common\model;


use think\Model;

class ProxyAppUpdateErrorLog extends Model
{
    protected $table="proxy_app_update_error_log";

}