<?php


namespace app\common\model;


use think\Model;

class DownloadUrl extends Model
{
    protected $table="download_url";

}