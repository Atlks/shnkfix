<?php

namespace app\common\model;

use think\Model;

/**
 * 收费
 */
class ProxyBaleRate extends Model
{
    protected $table='proxy_bale_rate';
}
