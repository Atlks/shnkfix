<?php


namespace app\common\model;


use think\Model;

class AppResignInstallCallback extends Model
{
    protected $table="app_resign_install_callback";


}