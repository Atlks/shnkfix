<?php


namespace app\common\model;


use think\Model;

class ProxyAppApkDownloadLog extends Model
{
    protected $table='proxy_app_apk_download_log';

}