<?php


namespace app\common\model;


use think\Model;

class ResignSignStr extends Model
{
    protected $table="resign_sign_str";

}