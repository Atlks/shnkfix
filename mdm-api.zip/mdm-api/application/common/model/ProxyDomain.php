<?php

namespace app\common\model;

use think\Model;

/**
 * 代理域名表
 */
class ProxyDomain extends Model
{
    protected $table='proxy_user_domain';
}
