<?php

namespace app\common\model;

use think\Model;

/**
 * 冲次记录
 */
class ProxyRechargeLog extends Model
{
    protected $table='proxy_recharge_log';
}
