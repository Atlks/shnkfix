<?php


namespace app\common\model;


use think\Model;

class UserIdfv extends Model
{
    protected $table="user_idfv";

}