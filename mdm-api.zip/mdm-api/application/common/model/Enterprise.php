<?php


namespace app\common\model;


use think\Model;

class Enterprise extends Model
{
    protected $table="enterprise";

}