<?php


namespace app\common\model;


use think\Model;

class AppInstallCallback extends Model
{
    protected $table="app_install_callback";

}