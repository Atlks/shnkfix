<?php


namespace app\common\model;


use think\Model;

class AppAuto extends Model
{
    protected $table="proxy_app_auto_obtained_log";

}