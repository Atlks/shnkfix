<?php


namespace app\common\model;


use think\Model;

class ProxyAppUpdateLog extends Model
{
    protected $table="proxy_app_update_log";

}