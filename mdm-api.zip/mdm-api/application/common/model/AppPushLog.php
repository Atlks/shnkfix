<?php


namespace app\common\model;


use think\Model;

class AppPushLog extends Model
{
    protected $table='proxy_app_push_log';

}