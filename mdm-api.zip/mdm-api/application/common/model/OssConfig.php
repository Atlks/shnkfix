<?php


namespace app\common\model;


use think\Model;

class OssConfig extends Model
{

    protected $table="oss_config";

}