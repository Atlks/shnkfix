<?php


namespace app\common\model;


use think\Model;

class ProxyUserDomain extends Model
{
    protected $table='proxy_user_domain';

}