<?php

namespace app\common\model;

use think\Model;

/**
 * 应用
 */
class ProxyApp extends Model
{
    protected $table='proxy_app';
}
