<?php


namespace app\common\model;


use think\Model;

class ProxyUserMoneyLogV1 extends Model
{
    protected $table="proxy_user_money_log_v1";

}