<?php

namespace app\common\model;

use think\Model;

/**
 * 下载
 */
class ProxyDownload extends Model
{
    protected $table='proxy_download';
}
